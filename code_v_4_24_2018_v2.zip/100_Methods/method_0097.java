	//private Configuration oldConfig = null;
	@Override
	public void onConfigurationChanged(Configuration newConfig)
	{
		super.onConfigurationChanged(newConfig);
		updateScreenOrientation();
		
		if (oldConfig != null)
		{
			int diff = newConfig.diff(oldConfig);
			Log.i("SDL", "onConfigurationChanged(): " + " diff " + diff +
					((diff & ActivityInfo.CONFIG_ORIENTATION) == ActivityInfo.CONFIG_ORIENTATION ? " orientation" : "") +
					((diff & ActivityInfo.CONFIG_SCREEN_SIZE) == ActivityInfo.CONFIG_SCREEN_SIZE ? " screen size" : "") +
					((diff & ActivityInfo.CSSS) == ActivityInfo.CSSS ? " config smallest screen size" : "") +
					" " + newConfig.toString());
		}
		oldConfig = new Configuration(newConfig);
		
	}