    /**
     * Returns the indices of the non-null datasets in the specified order.
     * 
     * @param drso  the order (<code>null</code> not permitted).
     * 
     * @return The list of indices. 
     */
    private List<Integer> getDatasetIndices(DatasetRenderingSpecifiedOrder drso) {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry<Integer, XYDataset> entry : this.datasets.entrySet()) {
            if (entry.getValue() != null) {
                result.add(entry.getKey());
            }
        }
        Collections.sort(result);
        if (drso == DatasetRenderingSpecifiedOrder.REVERSE) {
            Collections.reverse(result);
        }
        return result;
    }