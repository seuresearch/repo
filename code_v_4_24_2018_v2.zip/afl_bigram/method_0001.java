//Print list of affiliated faculty members
// forms from applications forms list
void pAFL(ArraryList<Member> afl){
	for(Member mem : afl){
		println(mem)
	}
}