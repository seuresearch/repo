"""-------------------------------------------
This tool expands abbreviations in source code 
using a probabilistic model based on Bayesian 
inference and relay on Unigram and Bigram 
language models.
----------------------------------------------
Updated 4/24/2018 
----------------------------------------------
Note: To run this code, you need to install the 
following libraries:
Python v4.11.18
pip3 install wordsegment
pip3 install python-docx
----------------------------------------------"""
#======== Import ============================
import os, fnmatch, glob, re, csv, math, itertools, time, sys
from collections import OrderedDict
from decimal import Decimal
from docx import Document
from docx.shared import Inches, Mm, RGBColor
from docx.enum.section import WD_ORIENT
from docx.text.run import Font, Run
from docx.enum.table import WD_TABLE_ALIGNMENT
from collections import defaultdict
from time import gmtime, strftime
from wordsegment import load, segment
load()

#======== Constants ==========================
"Two types of repositories when applicable: "
"(a) Natural Language Repository (NLR), which"
" is a collection of one Terabyte of web corpus,"
"such as textbooks and news archives, and"
"(b) Source Code Repository (SCR), which is"
" obtained from 0.7 million open source "
"software projects hosted on GitHub."
"Abbreviations Repository (Abb_UNI.csv) from 0.7 million"
"open source software projects hosted on GitHub."
repositories = ["NLR_UNI.csv", "NLR_BI.csv", "SCR_UNI.csv", "SCR_BI.csv", "Abb_UNI.csv"]

"Unwanted-Words are excluded set of reserved words used"
"in programming languages (e.g., null, if, and for),"
"and conjunction words (e.g., and, or, and since)."
"More reserved words need to be added when other"
"programming languages are included in Source Code Repository."
unwantedWords = ["break", "null", "private", "protected", "public",
                 "switch", "throw", "throws", "true", "true", "try",
                 "void", "while", "close", "return", "rary", "if",
                 "for", "and", "nor", "but", "or", "yet", "so", "yet",
                 "the", "that", "this", "those", "their", "they", "since",
                 "though", "although", "because", "by", "at", "till",
                 "when", "whenever", "where", "wherever", "while", "as",
                 "once", "unless", "until", "both", "either", "not",
                 "no", "yes", "also", "whether", "ar", "from", "br",
                 "new", "uri", "arg", "jc", "cal", "an", "ie", "in",
                 "egl", "tostring", "nbr", "keyset",
                 "else", "will", "pi", "halign", "minmax", "etc", "b",
                 "there", "do", "classpath", "really", "illegalaccessexception"
                 "InstantiationException", "get", "are", "nosuchmethodexception"
                 "arraylist", "and", "per", "sqlexception", "sdl", "tid",
                 "println", "pp", "sn", "maxm", "scalex"]
				 
#======== The prior knowledge calulation ===========
"Abbreviation Type Choosing (ATC) strategy."
"Abbreviation (CCA) and Nonconsecutive Characters Abbreviation (NCA)."
def getATC(s, w):
    if s[0:] == w[0:len(s)]:
        return "CCA"
    else:
        return "NCA"

"The probability of Abbreviation Type Choosing (ATC) strategy"
def get_P_ATC(ATC):
    if ATC=="CCA":
        return 0.8393
    else:
        return 0.1609

"Typing Effort Saving (TES) strategy."
def getTES(s, w):
    return round((1-(len(s)/len(w))), 3)

"The probability of Typing Effort Saving (TES) strategy."
def get_P_TES(TES):
    p_TES = 0.0000000001
    if TES <= 0.09:
        p_TES = 0.008594958
    elif TES <= 0.19:
        p_TES = 0.050616912
    elif TES <= 0.29:
        p_TES = 0.036402174
    elif TES <= 0.39:
        p_TES = 0.059484108
    elif TES <= 0.49:
        p_TES = 0.053300405
    elif TES <= 0.59:
        p_TES = 0.142312666
    elif TES <= 0.69:
        p_TES = 0.188466811
    elif TES <= 0.79:
        p_TES = 0.201689823
    elif TES <= 0.89:
        p_TES = 0.219249205
    elif TES <= 0.99:
        p_TES = 0.039882937
    return p_TES

"Context Sensitiveness (CS) strategy."
def getCS(s_lineNumber, c_lineNumber):
    return (abs(int(s_lineNumber) - int(c_lineNumber)))

"The probability of Context Sensitiveness (CS) strategy."
def get_P_CS(CS):
    return 0.83*math.exp(-2.53*CS)

"The probability of the prior knowledge."
def get_P_A_C(P_ATC, P_TES, P_CS):
    return (P_ATC*P_TES*P_CS)
	
#======== The other probabilities ===========
"The frequency of a word in some repository"
"based on some domain and language model"
"We use Laplace add-one smoothing method"
"to increase the zero probability of"
"an abbreviation to a small positive number."
"This prevents the denominator of term from "
"being a zero by counting an abbreviation"
"once if it is the First-Time-Seen (FTS)"
def getFreq(w, domain, languageModel, repoDict):
    try:
        freq = repoDict[domain+'|'+languageModel][1][w]
    except KeyError: #First-Time-Seen (FTS)
        freq = -1
    return freq

'Get the probability of word'
def get_P_W(freq, sizeOfRepo):
    if freq == -1:
        sizeOfRepo = sizeOfRepo + 1
        freq = 1
    P_W = (int(freq) / int(sizeOfRepo))
    return P_W


"The final estimation (probability) of the likelihood"
" that a candidate C being the correct expandion"
"for a given abbreviation A, P(C|A)"
def get_P_C_A(P_A_C, P_C, P_A):
    return ((P_A_C*P_C)/P_A)

"Because the abbreviation artitioned into multiple"
"segment sequences with different sizes, we "
"normalize P(C|A), so that long expansions have "
"fair compareson with shorter expansions."
def get_P_C_A_normalize(P_C_A, numOfSegments):
    return math.pow(P_C_A,(1/numOfSegments))

#======== Functions ========================================
"Making output folder"
def makeOutputFolder(outputFolder):
    if not os.path.exists(outputFolder):
        os.makedirs(outputFolder)
    return 0

"Get the frequencies of all "
"in one dictionay as follows: "
"{'domain|languageModel': ['sizeOfRepo','{'key':freq, 'key':freq, ....}']}:"
def getRepoDict(repositories):
    try:
        repoDict = {}
        for repo in repositories:
            print("Reading repository: "+str(repo[:-4]))
            innerList = []
            innerDict = {}
            sizeOfRepo = 0
            with open(os.getcwd()+"/static/"+repo) as f:
                repoFile = csv.reader(f, delimiter=',')
                for line in repoFile:
                    sizeOfRepo +=(int(line[1]))
                    innerDict[line[0]] = line[1]
            innerList.append(sizeOfRepo)
            innerList.append(innerDict)
            repoName = repo[:-4].split('_')
            print(str(repo[:-4])+" size = "+str(sizeOfRepo))
            repoDict[repoName[0]+'|'+repoName[1]] = innerList
    except Exception as e:
        print("Error in getRepoDict() says: "+str(e))
    return repoDict

"Finding the csv file in the input folder"
def findAbbCSVFile(pattern, inPath):
    listOfCSVFiles = []
    try:
        for file in os.listdir(inPath):
            if file.endswith(".csv")==1:
                listOfCSVFiles.append(file)
    except Exception as e:
        print("Error in findAbbCSVFile() says: "+str(e))
    return listOfCSVFiles

"List all files in the input folder"
def findListOfFiles(inPath):
    listOfFiles = []
    try:
        for file in os.listdir(inPath):
            if file.endswith(".csv")==0:
                listOfFiles.append(file)
    except Exception as e:
        print("Error in findListOfFiles() says: "+str(e))
    return listOfFiles

"Getting the number of resocrs in a file"
def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

"Making sure the abbreviation CSV file in the input directory"
def makingSureAllfilesExist(inPath):
    dataList = []
    listOfCSVFiles = findAbbCSVFile("csv", inPath)
    if len(listOfCSVFiles)==1:
        print("I found the abbreviation file, named: "+str(listOfCSVFiles[0]))
    else:
        print("I found multiple abbreviation files, and they are: "+str(listOfCSVFiles))
        print("Please make sure you have only one CSV file contains all the abbreviations")
        sys.exit()
        
    listOfFiles = findListOfFiles(inPath)
    if len(listOfFiles)==1:
        print("I found only one source code file, named: "+str(listOfFiles[0]))
        print("I will print calculations details since it is only one file.")
    else:
        #print("We found multiple source code files, and they are: "+str(listOfFiles))
        print("I will print summary for each file.")
    if len(listOfCSVFiles) !=0 or len(listOfFiles) !=0:
        dataList.append(listOfCSVFiles)
        numOfLines= file_len(inPath+str(listOfCSVFiles[0]))
        dataList.append(numOfLines)
        
        dataList.append(listOfFiles)
        numOfLines= len(listOfFiles)
        dataList.append(numOfLines)
    return dataList



"Making sure the number of abbreviaitons in the CSV file matches the"
"number of given source code files"
def makeSureAbbFileMatchesNumbers(dataList):
    numOfAbb = dataList[1]
    numOfSC = dataList[3]
    if numOfAbb == numOfSC:
        return 1
    else:
        return 0

"Reading Abbreviations Sets from the 'csv' file"
def readAbbSets(abbCSVFile):
    abbSets = {}
    with open(abbCSVFile) as f:
        fileLines = csv.reader(f, delimiter=',')
        i=1
        for line in fileLines:
            if len(line) > 1: #Abbreviation (A), Abbreviation Line Number, Manually found expansion for comparison
                abbSets[i]=[str(line[0]).lower(), line[1], str(line[2]).lower()]
                i=i+1
    return abbSets

"Geting Abbreviation Sequences"
def getSeq(A):
    A_Sequences = []
    chars = list(A)
    for ch in itertools.product(range(len('01')), repeat=len(chars)-1):
        A_Sequences.append(''.join([chars[i]+ch[i]*'|' for i in range(len(ch))])+chars[-1])
    return A_Sequences

"Get the abbreviation unique segments"
def getUniqueSeg(abbSeq):
    allSegmetns = [parts for seg in abbSeq for parts in seg.split('|')] 
    return list(set(allSegmetns))

"Reading source code file into a list"
"of lines of code"
def readCode(file):
    linesOfCode = []
    with open(file) as f:
        linesOfCode = [word.strip() for word in f]
    return linesOfCode

"Extracting all candidates (single words)"
"Removing unwanted words and charachters and spliting"
"concatenating strings using wordsegment 0.6.2’ by Jenks"
def extractCandidates(A, A_LineNum, linesOfCode, unwantedWords):
    cleanLinesOfCode = []
    candidatesWithLineNumbers = {}
    lineNumber = 1
    found = 0
    for line in linesOfCode:
        onlyCharLine = ' '.join(re.findall('[a-zA-Z]+', line))
        words = onlyCharLine.split()
        segmentedWords = []
        if len(words)> 0:
            for word in words:
                if len(word)>0:
                    wordParts = segment(word)
                    for part in wordParts:
                        segmentedWords.append(part)
                else:
                    segmentedWords.append(word)
        else:
            segmentedWords = words
        unwantedWords.append(A.lower())
        segmentedWords = [word for word in segmentedWords if (word.lower() not in unwantedWords)]
        oneLine = ' '.join(segmentedWords)
        if len(oneLine)>0:
            words = oneLine.split()
            for word in words:
                word = word.lower()
                if word[0] in list(A) and len(word)>=2:
                    if word in candidatesWithLineNumbers:
                        newDist = abs(int(A_LineNum)-int(lineNumber))
                        if newDist <= candidatesWithLineNumbers[word][0]:
                            candidatesWithLineNumbers[word][0] = newDist
                            candidatesWithLineNumbers[word][1] = lineNumber
                    else:
                        candidatesWithLineNumbers[word] = [abs(int(A_LineNum)-int(lineNumber)), lineNumber]
        lineNumber = lineNumber + 1
    return candidatesWithLineNumbers

"Getting the segments and their unigram candidates"
def getSegmentsWithCandidates(candidatesWithLineNumbers, A_UniqueSegmetns):
    segmentsWithCandidates = {}
    for segment in A_UniqueSegmetns:
        for word in candidatesWithLineNumbers:
            if word not in A_UniqueSegmetns:
                okToAdd = False
                if len(word)>len(segment):
                    if segment[0] == word[0] and len(segment) == 1:
                        okToAdd = True
                    elif segment[0] == word[0] and len(segment)>1:
                        if segment == word[0:(len(segment))]:
                            okToAdd = True
                        else:
                            okToAdd = True
                            i= 1
                            oldIndex = 0
                            while i<len(segment):
                                currentIndex = word[oldIndex+1:].find(segment[i])
                                if currentIndex== -1 or currentIndex < oldIndex:
                                    okToAdd = False
                                else:
                                    oldIndex = currentIndex
                                i+=1
                if okToAdd:
                    if segment not in segmentsWithCandidates:
                        segmentsWithCandidates[segment] = [word]
                    else:
                        segmentsWithCandidates[segment].append(word)
    return segmentsWithCandidates

"Getting the available abbreviation sequences"
def getAvailableAbbSeq(segmentsWithCandidates, A_Sequences):
    availableAbbSeq = []
    for sequence in A_Sequences:
        parts = sequence.split('|')
        i = 0
        okToAdd = True
        while i< len(parts):
            if parts[i] not in segmentsWithCandidates:
                okToAdd = False
            i=i+1
        if okToAdd:
            availableAbbSeq.append(sequence)
    return availableAbbSeq

"Getting Potential Expansions"
def getPotentialExpansions(segmentsWithCandidates, candidatesWithLineNumbers, A_UniqueSegmetns, A_Sequences):
    availableAbbSeq = getAvailableAbbSeq(segmentsWithCandidates, A_Sequences)
    potentialExpansions = {}
    for sequence in availableAbbSeq:
        segments = sequence.split('|')
        i = 0
        expansionList = []
        expansionList2 = []
        while i<len(segments):           
            expansionList.append(segmentsWithCandidates[segments[i]])
            i=i+1
        listOfPotentials = list(itertools.product(*expansionList))
        if len(segments)>=1:#Check for duplicates
            for each in listOfPotentials:
                if len(each) == len(set(each)):
                    expansionList2.append(each)
        potentialExpansions[sequence]= expansionList2
    return potentialExpansions

#======== Calculations functions ===============================
"Compute the all the probabilites for one word given a segment"
def computeProbabilities(s, w, s_LineNum, w_lineNum, domain, languageModel, repoDict):
    ATC = getATC(s, w)
    P_ATC = get_P_ATC(ATC)
    
    TES = getTES(s, w)
    P_TES = get_P_TES(TES)
    
    CS = getCS(s_LineNum, w_lineNum)
    P_CS = get_P_CS(CS)

    P_S_W = get_P_A_C(P_ATC, P_TES, P_CS)

    wFreq = getFreq(w, domain, languageModel, repoDict)
    wSizeOfRepo = repoDict[domain+'|'+languageModel][0]
    P_W = get_P_W(wFreq, wSizeOfRepo)

    sFreq = getFreq(s, "Abb", "UNI", repoDict)
    sSizeOfRepo = repoDict["Abb|UNI"][0]
    P_S = get_P_W(sFreq, sSizeOfRepo)
    
    P_S_W = get_P_C_A(P_S_W, P_W, P_S)
    return {"s_LineNum": s_LineNum, "w_lineNum": w_lineNum, "ATC": ATC, "P_ATC": P_ATC,
            "TES": TES, "P_TES": P_TES, "CS": CS, "P_CS": P_CS, "P_S_W": P_S_W, "wFreq": wFreq,
            "P_W": P_W, "sFreq": sFreq, "P_S": P_S, "P_S_W":P_S_W}

"Compute the unigram-based model to find the best candidate"
def computeUsingUnigramBasedModel(potentialExpansions, A_LineNum, candidatesWithLineNumbers, domain, repoDict):
    resultsDict = {}
    for sequence in potentialExpansions:
        segments = sequence.split('|')
        for expansion in potentialExpansions[sequence]:
            innerDict = {}
            i = 0
            P_A_C = 1
            P_C = 1
            P_A = 1
            while i<len(segments):
                probabilities = computeProbabilities(str(segments[i]), str(expansion[i]), A_LineNum,
                                candidatesWithLineNumbers[expansion[i]][1], domain, "UNI", repoDict)
                innerDict[str(segments[i])+'|'+str(expansion[i])]= probabilities
                P_A_C *= probabilities["P_ATC"]*probabilities["P_TES"]*probabilities["P_CS"]
                P_C *= probabilities["P_W"]
                P_A *= probabilities["P_S"]
                i +=1
            P_A_C = math.pow(P_A_C,(1/len(segments)))
            P_C = math.pow(P_C,(1/len(segments)))
            P_A = math.pow(P_A,(1/len(segments)))
            P_C_A = get_P_C_A(P_A_C, P_C, P_A)
            P_C_A_normalize = P_C_A #get_P_C_A_normalize(P_C_A, len(segments))
            resultsDict[str(sequence)+':'+str('|'.join(expansion))] = {"sequence": str(sequence),
            "expansion": str('|'.join(expansion)), "P_C_A_normalize": P_C_A_normalize,"P_A_C": P_A_C,
            "P_C":P_C, "P_A":P_A, "probabilities": innerDict}
    if len(resultsDict) != 0:
        resultsDictSorted = sorted(resultsDict.items(), key=lambda x: x[1]["P_C_A_normalize"], reverse=True)
    else:
        resultsDictSorted = {}
    return resultsDictSorted

"Compute the bigram-based model to find the best candidate"
def computeUsingBigramBasedModel(potentialExpansions, A_LineNum, candidatesWithLineNumbers, domain, repoDict):
    resultsDict = {}
    for sequence in potentialExpansions:
        segments = sequence.split('|')
        A = ' '.join(segments)
        if len(segments)>1:
            for expansion in potentialExpansions[sequence]:
                innerDict = {}
                i = 0
                P_A_C = 1
                while i<len(segments):
                    probabilities = computeProbabilities(str(segments[i]), str(expansion[i]), A_LineNum,
                                    candidatesWithLineNumbers[expansion[i]][1], domain, "UNI", repoDict)
                    innerDict[str(segments[i])+'|'+str(expansion[i])]= probabilities
                    P_A_C *= probabilities["P_ATC"]*probabilities["P_TES"]*probabilities["P_CS"]
                    i +=1
                    
                "Computing P(C) and P(A) in bigram fasion: P(A,B,C,D)= P(A)P(B|A)P(C|A,B)P(D|A,B,C)"
                wSizeOfRepoUni = repoDict[domain+'|UNI'][0]
                wFreq0 = getFreq(str(expansion[0]), domain, "UNI", repoDict)
                P_W0 = get_P_W(wFreq0, wSizeOfRepoUni)
                P_C = P_W0
                
                sSizeOfRepo = repoDict["Abb|UNI"][0]
                #sFreq0 = getFreq(str(segments[0]), "Abb", "UNI", repoDict)
                sFreq0 = getFreq(str(A), "Abb", "UNI", repoDict)
                P_S0 = get_P_W(sFreq0, sSizeOfRepo)
                P_A = P_S0

                wSizeOfRepoBi = repoDict[domain+'|BI'][0]
                j = 0
                while j<len(segments)-1:
                    wFreq1 = getFreq(str(expansion[j])+" "+str(expansion[j+1]), domain, "BI", repoDict)
                    P_W1 = get_P_W(wFreq1, wSizeOfRepoBi)
                    wFreq2 = getFreq(str(expansion[j]), domain, "UNI", repoDict)
                    P_W2 = get_P_W(wFreq2, wSizeOfRepoUni)
                    P_C *= P_W1/P_W2

                    sFreq1 = getFreq(str(segments[j])+" "+str(segments[j+1]), "Abb", "UNI", repoDict)
                    P_S1 = get_P_W(sFreq1, sSizeOfRepo)
                    sFreq2 = getFreq(str(segments[j]), "Abb", "UNI", repoDict)
                    P_S2 = get_P_W(sFreq2, sSizeOfRepo)
                    P_A *= P_S1/P_S2
                    
                    j +=1
                P_A_C = math.pow(P_A_C,(1/len(segments)))
                P_C = math.pow(P_C,(1/len(segments)))
                P_A = math.pow(P_A,(1/len(segments)))
                P_C_A = get_P_C_A(P_A_C, P_C, P_A)
                P_C_A_normalize = get_P_C_A_normalize(P_C_A, len(segments))
                resultsDict[str(sequence)+':'+str('|'.join(expansion))] = {"sequence": str(sequence),
                "expansion": str('|'.join(expansion)), "P_C_A_normalize": P_C_A_normalize,"P_A_C": P_A_C,
                "P_C":P_C, "P_A":P_A, "probabilities": innerDict}
    if len(resultsDict) != 0:
        resultsDictSorted = sorted(resultsDict.items(), key=lambda x: x[1]["P_C_A_normalize"], reverse=True)
    else:
        resultsDictSorted = {}
    return resultsDictSorted

#======== Printing functions ===================================

"Printing the segments with their candidates and line numbers"
def printCandidatesWithLineNumbers(candidatesWithLineNumbers, segmentsWithCandidates, document):
    try:
        statment = "The segments with their candidates and line numbers: "
        document.add_paragraph(statment)
        table = document.add_table(rows=1, cols=4)
        table.style = 'Table Grid'
        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = '#'
        hdr_cells[1].text = 'Segment'
        hdr_cells[2].text = 'Word'
        hdr_cells[3].text = 'Line Number'
        print(statment)
        print('{:<3} {:<10} {:<20} {:<15}'.format("#", "Segment", "Word", "Line Number"))
        i = 1
        for segment in segmentsWithCandidates:
            for word in segmentsWithCandidates[segment]:
                lineNumber = candidatesWithLineNumbers[word][1]
                print('{:<3} {:<10} {:<20} {:<15}'.format(str(i).zfill(2), str(segment), str(word), str(lineNumber)))
                row_cells = table.add_row().cells
                row_cells[0].text = '{:<3}'.format(str(i).zfill(2))
                row_cells[1].text = '{:<10}'.format(str(segment))
                row_cells[2].text = '{:<20}'.format(str(word))
                row_cells[3].text = '{:<15}'.format(str(lineNumber))
                i +=1
        document.add_paragraph("")
    except Exception as e:
        print("Error in printCandidatesWithLineNumbers() says: "+str(e))
    return document

"Printing the potential expansions"
def printPotentialExpansions(potentialExpansions, document):
    try:
        statment = "The potential expansions: "
        document.add_paragraph(statment)
        table = document.add_table(rows=1, cols=3)
        table.style = 'Table Grid'
        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = '#'
        hdr_cells[1].text = 'Sequence'
        hdr_cells[2].text = 'Expansion'
        print(statment)
        print('{:<5} {:<15} {:<60}'.format("#", "Sequence", "Expansion"))
        i = 1
        for sequence in potentialExpansions:
            for expansion in potentialExpansions[sequence]:
                print('{:<5} {:<15} {:<60}'.format(str(i).zfill(2), "<"+str(sequence)+">", "<"+str('|'.join(expansion))+">"))
                row_cells = table.add_row().cells
                row_cells[0].text = '{:<5}'.format(str(i).zfill(2))
                row_cells[1].text = '{:<15}'.format("<"+str(sequence)+">")
                row_cells[2].text = '{:<60}'.format("<"+str('|'.join(expansion))+">")
                i +=1
        document.add_paragraph("")
    except Exception as e:
        print("Error in printPotentialExpansions() says: "+str(e))
    return document

"Printing the computations details"
def printComputationsDetails(modelUSed, domain, resultsDictSorted, A_Expansion, document):
    try:
        statment = "The computation details for ("+domain+"-"+modelUSed+"): "
        document.add_paragraph(statment)
        table = document.add_table(rows=1, cols=7)
        table.style = 'Table Grid'
        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = '#'
        hdr_cells[1].text = 'Sequence'
        hdr_cells[2].text = 'Expansion'
        hdr_cells[3].text = 'P_S_C'
        hdr_cells[4].text = 'P_C'
        hdr_cells[5].text = 'P_S'
        hdr_cells[6].text = 'P_C_S'
        print(statment)
        print('{:<5} {:<15} {:<45} {:<13} {:<13} {:<13} {:<13}'.format(
            "#", "Sequence", "Expansion", "P_S_C", "P_C", "P_S", "P_C_S"))
        i = 1
        for item in resultsDictSorted:
            row_cells = table.add_row().cells        
            if A_Expansion.split('|') == str(item[1]["expansion"]).split('|'):
                expansion = "[<"+str(item[1]["expansion"])+">]"
                row_cells[0].paragraphs[0].add_run(str(i).zfill(2)).font.color.rgb = RGBColor(0, 160, 0)#Green
                row_cells[1].paragraphs[0].add_run("<"+str(item[1]["sequence"])+">").font.color.rgb = RGBColor(0, 160, 0)#Green
                row_cells[2].paragraphs[0].add_run("<"+str(item[1]["expansion"])+">").font.color.rgb = RGBColor(0, 160, 0)#Green
                row_cells[3].paragraphs[0].add_run('{:.4g}'.format(item[1]["P_A_C"])).font.color.rgb = RGBColor(0, 160, 0)#Green
                row_cells[4].paragraphs[0].add_run('{:.4g}'.format(item[1]["P_C"])).font.color.rgb = RGBColor(0, 160, 0)#Green
                row_cells[5].paragraphs[0].add_run('{:.4g}'.format(item[1]["P_A"])).font.color.rgb = RGBColor(0, 160, 0)#Green
                row_cells[6].paragraphs[0].add_run('{:.4g}'.format(item[1]["P_C_A_normalize"])).font.color.rgb = RGBColor(0, 160, 0)#Green
                
            else:
                expansion = "<"+str(item[1]["expansion"])+">"
                row_cells[0].text = '{:<5}'.format(str(i).zfill(2))
                row_cells[1].text = '{:<15}'.format("<"+str(item[1]["sequence"])+">")
                row_cells[2].text = '{:<60}'.format("<"+str(item[1]["expansion"])+">")
                row_cells[3].text = '{:<60}'.format('{:.4g}'.format(item[1]["P_A_C"]))
                row_cells[4].text = '{:<60}'.format('{:.4g}'.format(item[1]["P_C"]))
                row_cells[5].text = '{:<60}'.format('{:.4g}'.format(item[1]["P_A"]))
                row_cells[6].text = '{:<60}'.format('{:.4g}'.format(item[1]["P_C_A_normalize"]))
                
            print('{:<5} {:<15} {:<45} {:<13} {:<13} {:<13} {:<13}'.format(
            str(i).zfill(2), "<"+str(item[1]["sequence"])+">",
                expansion,
                '{:.4g}'.format(item[1]["P_A_C"]), '{:.4g}'.format(item[1]["P_C"]),
                '{:.4g}'.format(item[1]["P_A"]), '{:.4g}'.format(item[1]["P_C_A_normalize"])))
            
            i +=1
        document.add_paragraph("")
    except Exception as e:
        print("Error in printComputationsDetails() says: "+str(e))
    return document

"Printing the header of all reults table"
def pringAllResultsHeader(table, document):
    table.style = 'Table Grid'
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = '#'
    hdr_cells[1].text = 'Abbreviation'
    hdr_cells[2].text = 'Manual Expansion'
    hdr_cells[3].text = 'NLR-UNI'
    hdr_cells[4].text = 'SCR-UNI'
    hdr_cells[5].text = 'NLR-BI'
    hdr_cells[6].text = 'SCR-BI'
    #print(statment)
    '''print('{:<5} {:<15} {:<30} {:<30} {:<30} {:<30} {:<30}'.format(
            "#", "Abbreviation", "Manual Expansion", "NLR-UNI", "SCR-UNI", "NLR-BI", "SCR-BI"))'''
    return document

"Printing the correct expansions accuracy for each language model using different domains"
def printAll(i, A, A_Expansion, expansions, table, document):
    NLR_UNI = ""
    SCR_UNI = ""
    NLR_BI = ""
    SCR_BI = ""
    latexStart = "wrong{"
    latexEnd = "}"
    try:
        row_cells = table.add_row().cells 
        row_cells[0].text = '{:<5}'.format(str(i).zfill(2))
        row_cells[1].text = '{:<15}'.format(str(A))
        row_cells[2].text = '{:<60}'.format(str(A_Expansion))
        if str(A_Expansion)== expansions["NLR-UNI"]:
            row_cells[3].paragraphs[0].add_run(str(expansions["NLR-UNI"])).font.color.rgb = RGBColor(0, 160, 0)#Green
            NLR_UNI = '['+str(expansions["NLR-UNI"])+']'
        else:
            row_cells[3].paragraphs[0].add_run(latexStart+str(expansions["NLR-UNI"])+latexEnd).font.color.rgb = RGBColor(255, 0, 0)#Red
            NLR_UNI = str(expansions["NLR-UNI"])
            
        if str(A_Expansion)== expansions["SCR-UNI"]:
            row_cells[4].paragraphs[0].add_run(str(expansions["SCR-UNI"])).font.color.rgb = RGBColor(0, 160, 0)#Green
            SCR_UNI = '['+str(expansions["SCR-UNI"])+']'
        else:
            row_cells[4].paragraphs[0].add_run(latexStart+str(expansions["SCR-UNI"])+latexEnd).font.color.rgb = RGBColor(255, 0, 0)#Red
            SCR_UNI = str(expansions["SCR-UNI"])

        if str(A_Expansion)== expansions["NLR-BI"]:
            row_cells[5].paragraphs[0].add_run(str(expansions["NLR-BI"])).font.color.rgb = RGBColor(0, 160, 0)#Green
            NLR_BI = '['+str(expansions["NLR-BI"])+']'
        else:
            row_cells[5].paragraphs[0].add_run(latexStart+str(expansions["NLR-BI"])+latexEnd).font.color.rgb = RGBColor(255, 0, 0)#Red
            NLR_BI = str(expansions["NLR-BI"])

        if str(A_Expansion)== expansions["SCR-BI"]:
            row_cells[6].paragraphs[0].add_run(str(expansions["SCR-BI"])).font.color.rgb = RGBColor(0, 160, 0)#Green
            SCR_BI = '['+str(expansions["SCR-BI"])+']'
        else:
            row_cells[6].paragraphs[0].add_run(latexStart+str(expansions["SCR-BI"])+latexEnd).font.color.rgb = RGBColor(255, 0, 0)#Red
            SCR_BI = str(expansions["SCR-BI"])
        
        '''print('{:<5} {:<15} {:<30} {:<30} {:<30} {:<30} {:<30}'.format(
                str(i).zfill(2),str(A), A_Expansion, NLR_UNI, SCR_UNI, NLR_BI, SCR_BI))'''
    except Exception as e:
        print("Error in printAll() says: "+str(e))
    return document

"Printing the footer of all results table"
def pringAllResultsFooter(totalAccuracy, numOfAbbs, table, document):
    document.add_paragraph("")
    print("Total correct expansions: "+str(totalAccuracy))
    document.add_paragraph("NLR: Natural Language Repository, SCR: Source Code Repository, UNI: Unigram, BI: Bigram")
    document.add_paragraph("")
    document.add_paragraph("Total correct expansions: ")
    document.add_paragraph("NLR-Uni: "+'{:<2}'.format(str(totalAccuracy["NLR-UNI"]))+", SCR-Uni: "+'{:<2}'.format(str(totalAccuracy["SCR-UNI"]))+", NLR-Bi: "+'{:<2}'.format(str(totalAccuracy["NLR-BI"]))+", SCR-Bi: "+'{:<2}'.format(str(totalAccuracy["SCR-BI"]))+".")
    for each in totalAccuracy:
        percentage = (totalAccuracy[each]/numOfAbbs)*100
        totalAccuracy[each] = "{:.2f}".format(percentage)+'%'
    document.add_paragraph("Accuracy Percentages: ")
    document.add_paragraph("NLR-Uni: "+'{:<2}'.format(str(totalAccuracy["NLR-UNI"]))+", SCR-Uni: "+'{:<2}'.format(str(totalAccuracy["SCR-UNI"]))+", NLR-Bi: "+'{:<2}'.format(str(totalAccuracy["NLR-BI"]))+", SCR-Bi: "+'{:<2}'.format(str(totalAccuracy["SCR-BI"]))+".")
    print("Accuracy Percentages: "+str(totalAccuracy))
    return document
#======== Main Function ========================================
"Main function"
def do(repositories, inputFolder, outputFolder, unwantedWords):
    start_time = time.time()
    timeAndDate = strftime("%m_%d_%Y_%H_%M_%S", gmtime())
    domains = ["NLR", "SCR"]
    languageModels = ["UNI", "BI"]
    # Reading repositories
    repoDict = getRepoDict(repositories)
    # Making sure the abbreviation CSV file in the input directory
    inPath = str(os.getcwd()+'/'+inputFolder+'/')
    dataList = makingSureAllfilesExist(inPath)
    if len(dataList)==0:
        print("""Make sure you have at least two files:
                (1) Abbreviation CSV file, (2) Source Code File""")
    else:
        if makeSureAbbFileMatchesNumbers(dataList):
            outPath = str(os.getcwd()+'/'+outputFolder+'/')
            makeOutputFolder(outputFolder)
            document = Document()
            document.add_heading('Result for "'+inputFolder+'"\n'+timeAndDate, 0)
            section = document.sections[-1]
            section.orientation = WD_ORIENT.LANDSCAPE
            section.page_height = Mm(240)
            section.page_width = Mm(327)
            abbSets = readAbbSets(inPath+'/'+str(dataList[0][0]))
            numOfAbbs = len(abbSets)
            if numOfAbbs==1:
                showDetails = True
            else:
                showDetails = False
            i = 1
            totalAccuracy = {"NLR-UNI":0, "SCR-UNI":0, "NLR-BI":0, "SCR-BI":0}
            expansions = {"NLR-UNI":"", "SCR-UNI":"", "NLR-BI":"", "SCR-BI":""}
            fileName = str(inputFolder)+"_results_"+str(timeAndDate)+".csv"
            f = open(outPath+fileName, 'w')
            f.write("#, Abbreviation, Original Expansion, NLR-Uni-Expansion, Match?, SCR-Uni-Expansion, Match?, NLR-Bi-Expansion, Match?, SCR-Bi-Expansion, Match?"+'\n')
            if not showDetails:
                statment = "The correct expansions accuracy for each language model using different domains."
                document.add_paragraph(statment)
                table = document.add_table(rows=1, cols=7)
                document = pringAllResultsHeader(table, document)
            for file in dataList[2]:
                A = abbSets[i][0]
                A_LineNum = abbSets[i][1]
                A_Expansion = abbSets[i][2]
                A_Sequences = getSeq(A)
                A_UniqueSegmetns =getUniqueSeg(A_Sequences)
                if showDetails: print("Abbrevaiton: "+str(A))
                if showDetails: print("Abbrevaiton Line Number: "+str(A_LineNum))
                if showDetails: print("Abbrevaiton Manual Expansion: "+str(A_Expansion))
                if showDetails: print("Abbrevaiton Sequences: "+str(A_Sequences))
                if showDetails: print("Abbrevaiton Unique Segments: "+str(A_UniqueSegmetns))
                if showDetails: print("File name: "+str(file))
                if not showDetails:print("("+str(i).zfill(3)+") Expanding '"+str(A)+"', ...      ", end="", flush=True)
                linesOfCode = readCode(inPath+file)
                candidatesWithLineNumbers = extractCandidates(A, A_LineNum, linesOfCode, unwantedWords)
                #print("candidatesWithLineNumbers: "+str(candidatesWithLineNumbers))
                segmentsWithCandidates = getSegmentsWithCandidates(candidatesWithLineNumbers, A_UniqueSegmetns)
                #print("segmentsWithCandidates: "+str(segmentsWithCandidates))
                if showDetails: document = printCandidatesWithLineNumbers(candidatesWithLineNumbers, segmentsWithCandidates, document)
                potentialExpansions = getPotentialExpansions(segmentsWithCandidates, candidatesWithLineNumbers, A_UniqueSegmetns, A_Sequences)
                #print("potentialExpansions: "+str(potentialExpansions))
                if showDetails: document = printPotentialExpansions(potentialExpansions, document)
                foundExpansion = "Not Found"
                resultList = []
                for langModel in languageModels:
                    for domain in domains:
                        resultsDict = {}
                        if langModel=="UNI":
                            resultsDict = computeUsingUnigramBasedModel(potentialExpansions, A_LineNum, candidatesWithLineNumbers, domain, repoDict)
                        elif len(A)>1:
                            resultsDict = computeUsingBigramBasedModel(potentialExpansions, A_LineNum, candidatesWithLineNumbers, domain, repoDict)
                        try:   
                            if len(resultsDict[0][1]["expansion"])>1:
                                foundExpansion = resultsDict[0][1]["expansion"]
                        except KeyError:
                            foundExpansion = ""
                        if len(A)==1 and langModel=="BI":
                            foundExpansion = "NA"
                        expansions[str(domain)+'-'+str(langModel)] = foundExpansion
                        if showDetails and len(resultsDict)>1: document = printComputationsDetails(str(langModel), domain, resultsDict, A_Expansion, document)
                        if str(foundExpansion) == str(A_Expansion):
                            totalAccuracy[str(domain)+'-'+str(langModel)] += 1
                            resultList.append(1)
                        else:
                            resultList.append(0)
                if not showDetails: document = printAll(i, A, A_Expansion, expansions, table, document)
                oneRow = str(i)+','+str(A)+','+str(A_Expansion)+','+str(expansions["NLR-UNI"])+','+str(resultList[0])+','+str(expansions["SCR-UNI"])+','+str(resultList[1])+','+str(expansions["NLR-BI"])+','+str(resultList[2])+','+str(expansions["SCR-BI"])+','+str(resultList[3])
                f.write(str(oneRow)+'\n')
                i +=1
                print(str(resultList)+" ... [DONE]")
                #endfor
            #endfor
            f.close()
            if not showDetails: document = pringAllResultsFooter(totalAccuracy, numOfAbbs, table, document)
        else:
            print("""Make sure that the number of abbreviaitons in the CSV
                    file matches the number of given source code files""")
    #endif
    timeDif = time.time()-start_time
    m, s = divmod(timeDif, 60)
    h, m = divmod(m, 60)
    print("Total run time: %02d:%02d:%02d" % (h, m, s))
    try:
        document.add_paragraph("Total run time (H:M:S): %02d:%02d:%02d" % (h, m, s))
        document.save(outPath+str(inputFolder)+"_results_"+str(timeAndDate)+".docx")
        print("Done. Check the output folder ("+str(inputFolder)+") for detaild results.")
    except:
        print("Couldn't save the results to a file, please check the code")
    return 0
    
#======== Parameters ========================================
inputFolder = "100_Methods"
outputFolder = str(inputFolder)+"_output"
do(repositories, inputFolder, outputFolder, unwantedWords)
